#include <libc.h>

char buff[24];

int pid;

int add( int par1, int par2){
	__asm__ __volatile__ (
		"mov 0x8(%ebp),%edx\n\t"
		"mov 0xc(%ebp),%eax\n\t"
		"add %edx,%eax");
}

long inner(long n){
	int i;
	long suma;
	suma = 0;
	for	(i=0; i<n; i++) suma = suma + i;
	return suma;
}

long outer(long n){
	int	i;
	long acum;
	acum = 0;
	for	(i=0; i<n; i++) acum = acum + inner(i);
	return acum;
}

int __attribute__ ((__section__(".text.main")))
  main(void)
{

    write(1,"\ncalling getpid\n",16);
    int mypid = getpid();
    write(1,"called getpid\n",14);
    int pid = fork();
    if (pid > 0){
    	write(1,"I'm the parent: ",16);
    	itoa(mypid,buff);
    	write(1,buff,strlen(buff));
    	write(1," <--pid\n",8);
    	exit();
    }else{
    	write(1, "I'm the son: ",13);
    	itoa(mypid,buff);
    	write(1,buff,strlen(buff));
    	write(1," <--pid\n",8);
		for(;;);
	}
}
