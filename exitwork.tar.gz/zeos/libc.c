/*
 * libc.c 
 */

#include <libc.h>

#include <types.h>

int errno;

int perror()
{
  if(errno == 0) 
    write(1,"0\n",2);
  else {
    if(errno == -9)  write(1,"EBADF\n",6);
    else if(errno == -12) write(1,"ENOMEM\n",7);
    else if(errno == -13) write(1,"EACCES\n",7);
    else if(errno == -14) write(1,"EFAULT\n",7);
    else if(errno == -22) write(1,"EINVAL\n",7);
    else if(errno == -38) write(1,"ENOSYS\n",7);
    else write(1,"Unknown error\n",14);
  }
}

void itoa(int a, char *b)
{
  int i, i1;
  char c;
  
  if (a==0) { b[0]='0'; b[1]=0; return ;}
  
  i=0;
  while (a>0)
  {
    b[i]=(a%10)+'0';
    a=a/10;
    i++;
  }
  
  for (i1=0; i1<i/2; i1++)
  {
    c=b[i1];
    b[i1]=b[i-i1-1];
    b[i-i1-1]=c;
  }
  b[i]=0;
}

int strlen(char *a)
{
  int i;
  
  i=0;
  
  while (a[i]!=0) i++;
  
  return i;
}

int write (int fd, char * buffer, int size)
{
    int ret = -1;
    __asm__ __volatile__(
    "movl $4, %%eax\n\t"
    "int $0x80"
        : "=r" (ret)
        : "b" (fd), "c" (buffer), "d" (size) );
    
    if (ret >= 0) return ret;
    else 
    {
        errno = ret;
        return -1;
    }
}

int gettime() {
    int ret = -1;
    asm("movl $10, %%eax\n\t"
        "int $0x80"
        : "=r" (ret) );
    
    if (ret >= 0) return ret;
    else 
    {
        errno = ret;
        return -1;
    }
}

int getpid(){
  int ret = -1;
  asm("movl $20, %%eax\n\t"
    "int $0x80"
    : "=r" (ret) );

  if (ret >= 0) return ret;
  else 
  {
    errno = ret;
    return -1;
  }
}

int fork() {
  int ret = -1;
  asm("movl $2, %%eax\n\t"
      "int $0x80"
      : "=r" (ret) );
  
  if (ret >= 0) return ret;
  else 
  {
      errno = ret;
      return -1;
  }
}

void exit() {
    int ret = -1;
    asm("movl $1, %%eax\n\t"
        "int $0x80"
        : "=r" (ret) );
    
    if (ret >= 0) return ret;
    else 
    {
        errno = ret;
        return -1;
    }
}