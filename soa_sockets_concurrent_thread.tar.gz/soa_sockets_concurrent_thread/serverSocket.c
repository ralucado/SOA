#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>

#define MAX_SERVICES 1000

int petitionsToServe[MAX_SERVICES];
int index = 0;

sem_t sem_petitions;

void doService(int fd) 
{
	int i = 0;
	char buff[80];
	char buff2[80];
	int ret;
	int socket_fd = (int) fd;

	ret = read(socket_fd, buff, sizeof(buff));
	while(ret > 0) {
		buff[ret]='\0';
		sprintf(buff2, "Server [%d] received: %s\n", getpid(), buff);
		write(1, buff2, strlen(buff2));
		ret = write(fd, "caracola ", 8);
		if (ret < 0) {
			perror ("Error writing to socket");
			exit(1);
		}
		ret = read(socket_fd, buff, sizeof(buff));
	}
	if (ret < 0) {
		perror ("Error reading from socket");

	}
	sprintf(buff2, "Server [%d] ends service\n", getpid());
	write(1, buff2, strlen(buff2));

}

void waitForService()
{
	while (1)
	{
		sem_wait(&sem_petitions);
		// semafor begin block
		if (index != 0)
		{
			int fd = petitionsToServe[index];
			index = index - 1;
			sem_post(&sem_petitions);
			doService(fd);
		}
		else 
			sem_post(&sem_petitions);
	}
}

int main (int argc, char *argv[])
{
	int socketFD;
	int connectionFD;
	char buffer[80];
	int ret;
	int port;

	sem_init(sem_petitions,0,1)

	if (argc != 3)
	{
		strcpy (buffer, "Usage: MaxThreads ServerSocket PortNumber\n");
		write (2, buffer, strlen (buffer));
		exit (1);
	}

	int maxThreads = atoi(argv[1]);
	pthread_t thread_id[maxThreads];
	int i; 
	for(i=0; i < maxThreads; i++)
	{
		pthread_create( &thread_id[i], NULL, &waitForService, NULL );
	}

	port = atoi(argv[2]);
	socketFD = createServerSocket (port);
	if (socketFD < 0)
	{
		perror ("Error creating socket\n");
		exit (1);
	}

	while (1) {
		while(index >= MAX_SERVICES);
		connectionFD = acceptNewConnections (socketFD);
		if (connectionFD < 0)
		{
			perror ("Error establishing connection \n");
			deleteSocket(socketFD);
			exit (1);
		}

		// Semafor per bloquejar l'array petitionsToServe
		sem_wait(&sem_petitions);
		petitionsToServe[index] = fd;
		index = index + 1;
		sem_port(&sem_petitions);
		// end block
	}

}
