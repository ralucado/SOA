/*
* sys.c - Syscalls implementation
*/
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#define LECTURA 0
#define ESCRIPTURA 1

extern int zeos_ticks;
extern int pidglobal = 1337;

int check_fd(int fd, int permissions)
{
    if (fd!=1) return -9; /*EBADF*/
    if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
    return 0;
}

int sys_ni_syscall()
{
    return -38; /*ENOSYS*/
}

int sys_getpid()
{
    return current()->PID;
}

int ret_from_fork()
{
  return 0;
}

int sys_fork()
{

// creates the child process
    //a)
    struct list_head * c_pcb = list_first( &freequeue );
    if(c_pcb == NULL) return -12;
    list_del(c_pcb);
    struct task_struct * c_ts = list_head_to_task_struct(c_pcb);
    union task_union * c_tu = (union task_union*)c_ts;

    //b)
    struct task_struct * p_ts = current();
    union task_union * p_tu = (union task_union*)p_ts; 
    copy_data(current(), c_tu, sizeof(union task_union));

    //c)
    allocate_DIR(c_ts);

    //d)
    int pag;
    int new_ph_pag;
    int frames[NUM_PAG_DATA];
    for (pag=0;pag<NUM_PAG_DATA;pag++){
        new_ph_pag=alloc_frame();
        if (new_ph_pag < 0) { //no free frames left
            int i;
            for(i = 0; i < pag; i++)
                free_frame(frames[i]);
            list_add_tail(c_pcb, &freequeue);
            return -12;
        }
        else frames[pag] = new_ph_pag;
    }


    //e)
    //  i)
    //    A)
    page_table_entry * c_pt = get_PT(c_ts);
    page_table_entry * p_pt = get_PT(p_ts);
    for (pag=0; pag<NUM_PAG_KERNEL; pag++)
        set_ss_pag(c_pt, pag, get_frame(p_pt, pag));
    for (pag=0; pag<NUM_PAG_CODE; pag++)
        set_ss_pag(c_pt, PAG_LOG_INIT_CODE+pag, get_frame(p_pt, PAG_LOG_INIT_CODE+pag));
    //    B)
    for (pag=0;pag<NUM_PAG_DATA;pag++)
        set_ss_pag(c_pt,PAG_LOG_INIT_DATA+pag,frames[pag]);
    //  ii)
    //    A)
    for (pag=NUM_PAG_KERNEL+NUM_PAG_CODE; pag<NUM_PAG_KERNEL+NUM_PAG_CODE+NUM_PAG_DATA; pag++)
    {

        // Map one child page to parent's address space
        // TBD: podriamos usar siempre la pagina NUM_PAG_KERNEL+NUM_PAG_CODE+NUM_PAG_DATA ?
        set_ss_pag(p_pt, pag+NUM_PAG_DATA, get_frame(c_pt, pag));
        // apply mask by shifting 12 --> 2^12 = 4Kb = PAGE_SIZE
        //B)
        copy_data((void*)(pag<<12), (void*)((pag+NUM_PAG_DATA)<<12), PAGE_SIZE);
        del_ss_pag(p_pt, pag+NUM_PAG_DATA);
    }
    //    C)
    page_table_entry * p_dir = get_DIR(p_ts);
    set_cr3(p_dir);

    //f)
    //TBD: is this different than the position in the task_array table? what is the "task_array table"??? i dont even
    int PID = pidglobal++;

    //g)
    c_ts->PID = PID;          /* Process ID. This MUST be the first field of the struct. */
    c_ts->dir_pages_baseAddr = get_DIR(c_ts);
    //c_ts->kernel_esp = ?

    //h)
    unsigned long p_ebp;
    __asm__ __volatile__ (
        "movl %%ebp, %0\n\t"
        : "=g" (p_ebp)
    );
    unsigned long c_ebp = (unsigned long)p_ebp - (unsigned long)p_ts + (unsigned long)c_ts;
    c_ts->kernel_esp -= 4;
    c_tu->stack[c_ts->kernel_esp] = &ret_from_fork;
    c_ts->kernel_esp -= 4;
    c_tu->stack[c_ts->kernel_esp] = 0;

    //i)
    list_add_tail(&c_ts->list,&readyqueue);

    //to Test
    task_switch(c_ts);

    //j)
    return PID;
}


void sys_exit()
{  
}

int sys_write(int fd, char * buffer, int size)
{    
// Check the parameters
    int error = check_fd(fd,ESCRIPTURA);
    if(error < 0)
        return error;
    if (buffer == NULL) return -14;  // EFAULT -> bad address

    if (size < 0)
    return -22; //EINVAL -> invalid argument

    char localbuffer[size];

    error = copy_from_user(buffer, localbuffer, size);
    if ( error < 0) return error;
    error = sys_write_console(localbuffer, size);
    return error;    
}

int sys_gettime() 
{
    return zeos_ticks;
}