/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#define LECTURA 0
#define ESCRIPTURA 1

extern int zeos_ticks;

int check_fd(int fd, int permissions)
{
  if (fd!=1) return -9; /*EBADF*/
  if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
  return 0;
}

int sys_ni_syscall()
{
	return -38; /*ENOSYS*/
}

int sys_getpid()
{
	return current()->PID;
}

int sys_fork()
{
  int PID=-1;

  // creates the child process
  
  return PID;
}

void sys_exit()
{  
}
 
int sys_write(int fd, char * buffer, int size)
{    
   // Check the parameters
    int error = check_fd(fd,ESCRIPTURA);
    if(error != 0)
        return error;
    if (buffer == NULL)
        return -1;
    if (size < 0)
        return -1;
    
    int bytes_left = size;
    char localbuffer[512];
    while (bytes_left > 512)
    {
        copy_from_user(buffer, localbuffer, 512);
        error = sys_write_console(localbuffer, 512);
        bytes_left -= error;
        buffer += error;
    }
    if (bytes_left > 0)
    {
        copy_from_user(buffer, localbuffer, 512);
        error = sys_write_console(localbuffer, 512);
        bytes_left -= error;
    }
    
    return (size-bytes_left);    
}

int sys_gettime() 
{
    return zeos_ticks;
}