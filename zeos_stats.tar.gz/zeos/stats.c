#include <utils.h>

void update_stats(unsigned long *v, unsigned long *elapsed)
{    
  *v = *v + get_ticks() - *elapsed;
  *elapsed = get_ticks();
}