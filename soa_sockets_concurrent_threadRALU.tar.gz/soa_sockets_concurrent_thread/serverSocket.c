#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define MAX_SERVICES 1000

int petitionsToServe[MAX_SERVICES];
int currentPetitions;
//canviar per dos ints, punter de lectura i escritura, i usar vector com un buffer circular
//el semafor de petitions serveix per bloquejar quan hi ha massa peticions
sem_t sem_petitions;
sem_t sem_clients;
void doService(int fd) 
{
	int i = 0;
	char buff[80];
	char buff2[80];
	int ret;
	int socket_fd = (int) fd;

	ret = read(socket_fd, buff, sizeof(buff));
	while(ret > 0) {
		buff[ret]='\0';
		sprintf(buff2, "Server [%d] received: %s\n", getpid(), buff);
		write(1, buff2, strlen(buff2));
		ret = write(fd, "caracola ", 8);
		if (ret < 0) {
			perror ("Error writing to socket");
			exit(1);
		}
		ret = read(socket_fd, buff, sizeof(buff));
	}
	if (ret < 0) {
		perror ("Error reading from socket");

	}
	sprintf(buff2, "Server [%d] ends service\n", getpid());
	write(1, buff2, strlen(buff2));

}

void waitForService()
{
		sem_wait(&sem_clients);
		sem_wait(&sem_petitions);
		// semafor begin block
		write (2, "in serv", strlen ("in serv"));

		if (currentPetitions != 0)
		{
			int fd = petitionsToServe[currentPetitions];
			--currentPetitions;
			sem_post(&sem_petitions);
			doService(fd);
		}
		else 
		sem_post(&sem_petitions);
}

int main (int argc, char *argv[])
{
	int socketFD;
	int connectionFD;
	char buffer[80];
	int ret;
	int port;
	currentPetitions = 0;
	sem_init(&sem_petitions,0,1);
	sem_init(&sem_clients,0,0);
	if (argc != 3)
	{
		strcpy (buffer, "Usage: ServerSocket MaxThreads PortNumber\n");
		write (2, buffer, strlen (buffer));
		exit (1);
	}

	int maxThreads = atoi(argv[1]);
	pthread_t thread_id[maxThreads];
	int i; 
	for(i=0; i < maxThreads; i++)
	{
		pthread_create( &thread_id[i], NULL, (void*)waitForService, NULL );
	}

	port = atoi(argv[2]);
	socketFD = createServerSocket (port);
	if (socketFD < 0)
	{
		perror ("Error creating socket\n");
		exit (1);
	}

	while (1) {
		while(currentPetitions >= MAX_SERVICES){
			//nothing
		}
		int connectionFD = acceptNewConnections (socketFD);
		if (connectionFD < 0)
		{
			perror ("Error establishing connection \n");
			deleteSocket(socketFD);
			exit (1);
		}
		write (2, "in sem_pet", strlen ("in sem_pet"));

		// Semafor per bloquejar l'array petitionsToServe
		sem_wait(&sem_petitions);

		petitionsToServe[currentPetitions] = connectionFD;
		++currentPetitions;
		sem_post(&sem_clients);

		sem_post(&sem_petitions);
		// end block
	}

}
