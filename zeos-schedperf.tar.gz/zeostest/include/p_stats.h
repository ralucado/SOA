#ifndef __P_STATS_H__
#define __P_STATS_H__

void update_stats(unsigned long *v, unsigned long *elapsed);

#endif
