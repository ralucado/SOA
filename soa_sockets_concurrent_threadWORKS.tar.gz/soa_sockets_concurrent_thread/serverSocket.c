#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define MAX_SERVICES 3

int petitionsToServe[MAX_SERVICES];
int readPetitions;
int writePetitions;

//canviar per dos ints, punter de lectura i escritura, i usar vector com un buffer circular
//el semafor de petitions serveix per bloquejar quan hi ha massa peticions
sem_t sem_petitions;
sem_t sem_clients;
void doService(int fd) 
{
	int i = 0;
	char buff[80];
	char buff2[80];
	int ret;
	int socket_fd = (int) fd;

	ret = read(socket_fd, buff, sizeof(buff));
	while(ret > 0) {
		buff[ret]='\0';
		sprintf(buff2, "Server [%d] received: %s\n", getpid(), buff);
		write(1, buff2, strlen(buff2));
		ret = write(fd, "caracola ", 8);
		if (ret < 0) {
			perror ("Error writing to socket");
			exit(1);
		}
		ret = read(socket_fd, buff, sizeof(buff));
	}
	if (ret < 0) {
		perror ("Error reading from socket");

	}
	sprintf(buff2, "Server [%d] ends service\n", getpid());
	write(1, buff2, strlen(buff2));

}

void waitForService()
{
	while(1){
		sem_wait(&sem_clients);
		// semafor begin block
		int fd = petitionsToServe[readPetitions];
		sem_post(&sem_petitions);
		readPetitions=(readPetitions+1)%MAX_SERVICES;
		doService(fd);
	}
}

int main (int argc, char *argv[])
{
	int socketFD;
	int connectionFD;
	char buffer[80];
	int ret;
	int port;
	readPetitions = 0;
	writePetitions = 0;

	sem_init(&sem_petitions,0,MAX_SERVICES);
	sem_init(&sem_clients,0,0);
	if (argc != 3)
	{
		strcpy (buffer, "Usage: ServerSocket MaxThreads PortNumber\n");
		write (2, buffer, strlen (buffer));
		exit (1);
	}

	int maxThreads = atoi(argv[1]);
	pthread_t thread_id[maxThreads];
	int i; 
	for(i=0; i < maxThreads; i++)
	{
		pthread_create( &thread_id[i], NULL, (void*)waitForService, NULL );
	}

	port = atoi(argv[2]);
	socketFD = createServerSocket (port);
	if (socketFD < 0)
	{
		perror ("Error creating socket\n");
		exit (1);
	}

	while (1) {
		// Semafor per bloquejar l'array petitionsToServe quan hi ha mes de MAX_SERVICES
		write (2, "serv waiting\n", strlen ("serv waiting\n"));
		sem_wait(&sem_petitions);
		write (2, "serv go\n", strlen ("serv go\n"));


		int connectionFD = acceptNewConnections (socketFD);
		if (connectionFD < 0)
		{
			perror ("Error establishing connection \n");
			deleteSocket(socketFD);
			exit (1);
		}

		petitionsToServe[writePetitions] = connectionFD;
		writePetitions = (writePetitions+1)%MAX_SERVICES;
		sem_post(&sem_clients);
	}

}
